/* ════════════════════════════════════════════════════════════
   HELIX Audio — renderer.js
   Wszystko po stronie UI: kanały, efekty, makra, IPC
   ════════════════════════════════════════════════════════════ */

// ── Dane aplikacji ────────────────────────────────────────────────
const CHANNELS = [
  { id: 'mic',     label: 'MIC',     abbr: 'MC', vol: 72, muted: false, solo: false },
  { id: 'discord', label: 'DISCORD', abbr: 'DS', vol: 80, muted: false, solo: false },
  { id: 'chrome',  label: 'CHROME',  abbr: 'CH', vol: 55, muted: false, solo: false },
  { id: 'spotify', label: 'SPOTIFY', abbr: 'SP', vol: 65, muted: false, solo: false },
  { id: 'cs2',     label: 'CS2',     abbr: 'CS', vol: 88, muted: false, solo: false },
  { id: 'system',  label: 'SYSTEM',  abbr: 'SY', vol: 45, muted: false, solo: false },
  { id: 'obs',     label: 'OBS',     abbr: 'OB', vol: 60, muted: false, solo: false },
];

const FX_DEFS = [
  { key: 'ns',   title: 'NOISE SUPPRESS', on: true, rows: [
    { id: 'ns-thr', lbl: 'Threshold', min: -80, max: 0,   val: -40, unit: 'dB' },
    { id: 'ns-int', lbl: 'Intensity', min: 0,   max: 100, val: 75,  unit: '%' },
  ]},
  { key: 'ng',   title: 'NOISE GATE',     on: true, rows: [
    { id: 'ng-op',  lbl: 'Open',    min: -80, max: 0,   val: -30, unit: 'dB' },
    { id: 'ng-cl',  lbl: 'Close',   min: -80, max: 0,   val: -50, unit: 'dB' },
    { id: 'ng-rel', lbl: 'Release', min: 10,  max: 500, val: 100, unit: 'ms' },
  ]},
  { key: 'echo', title: 'ECHO CANCEL',    on: true, rows: [
    { id: 'ec-amt', lbl: 'Amount', min: 0, max: 100, val: 80, unit: '%' },
  ]},
  { key: 'eq',   title: 'EQ (3-BAND)',    on: false, rows: [
    { id: 'eq-lo',  lbl: 'Low',  min: -12, max: 12, val: 2,  unit: 'dB' },
    { id: 'eq-mid', lbl: 'Mid',  min: -12, max: 12, val: 0,  unit: 'dB' },
    { id: 'eq-hi',  lbl: 'High', min: -12, max: 12, val: -1, unit: 'dB' },
  ]},
  { key: 'comp', title: 'COMPRESSOR',     on: false, rows: [
    { id: 'co-thr', lbl: 'Threshold', min: -60, max: 0,  val: -20, unit: 'dB' },
    { id: 'co-rat', lbl: 'Ratio',     min: 1,   max: 20, val: 4,   unit: ':1' },
    { id: 'co-mk',  lbl: 'Makeup',    min: 0,   max: 24, val: 6,   unit: 'dB' },
  ]},
];

const MACROS = [
  { key: 'F1', action: 'MIC MUTE',  shortcutAction: 'mic-mute' },
  { key: 'F2', action: 'GAME SRC',  shortcutAction: null },
  { key: 'F3', action: 'OBS SCENE', shortcutAction: null },
  { key: 'F4', action: 'MUTE ALL',  shortcutAction: 'mute-all' },
  { key: 'F5', action: 'HEADSET',   shortcutAction: null },
  { key: 'F6', action: 'SPEAKERS',  shortcutAction: null },
  { key: 'F7', action: 'NOISE ON',  shortcutAction: null },
  { key: 'F8', action: 'RESET',     shortcutAction: 'reset' },
];

let vcOn      = true;
let animT     = 0;
let animFrame = null;

// ══════════════════════════════════════════════════════════════════
// BUDOWANIE UI
// ══════════════════════════════════════════════════════════════════

function buildChannels() {
  const grid = document.getElementById('ch-grid');
  grid.innerHTML = CHANNELS.map(ch => `
    <div class="channel" id="ch-${ch.id}">
      <div class="ch-avatar">${ch.abbr}</div>
      <div class="ch-name">${ch.label}</div>
      <div class="meter-fader">
        <div class="meter">
          <div class="m-fill" id="mf-${ch.id}" style="height:0"></div>
        </div>
        <div class="ftrack" id="ft-${ch.id}">
          <div class="fthumb" id="fh-${ch.id}"
               style="top:${Math.round((1 - ch.vol / 100) * 116)}px"></div>
        </div>
      </div>
      <div class="vol-val" id="vv-${ch.id}">${ch.vol}</div>
      <div class="ch-btns">
        <button class="cbtn" id="mb-${ch.id}" onclick="toggleMute('${ch.id}')">M</button>
        <button class="cbtn" id="sb-${ch.id}" onclick="toggleSolo('${ch.id}')">S</button>
      </div>
    </div>
  `).join('');

  CHANNELS.forEach(setupFader);
}

function setupFader(ch) {
  const thumb = document.getElementById('fh-' + ch.id);
  let drag = false, startY = 0, startTop = 0;

  thumb.addEventListener('mousedown', e => {
    drag = true;
    startY   = e.clientY;
    startTop = parseInt(thumb.style.top) || 0;
    e.preventDefault();
    e.stopPropagation();
  });

  document.addEventListener('mousemove', e => {
    if (!drag) return;
    const newTop = Math.min(116, Math.max(0, startTop + (e.clientY - startY)));
    thumb.style.top = newTop + 'px';
    ch.vol = Math.round(100 - (newTop / 116) * 100);
    document.getElementById('vv-' + ch.id).textContent = ch.vol;
    document.getElementById('ch-' + ch.id).classList.toggle('is-active', ch.vol > 0);
    // W przyszłości: wysłać do WASAPI
  });

  document.addEventListener('mouseup', () => { drag = false; });
}

function buildFX() {
  const panel = document.getElementById('fx-panel');
  panel.innerHTML =
    '<div class="sec-lbl">EFEKTY — MIC</div>' +
    FX_DEFS.map(s => `
      <div class="fx-sec">
        <div class="fx-hdr">
          <span class="fx-title">${s.title}</span>
          <div class="tog${s.on ? ' on' : ''}" id="tog-${s.key}"
               onclick="toggleFX('${s.key}')"></div>
        </div>
        ${s.rows.map(r => `
          <div class="fx-row">
            <span class="fx-lbl">${r.lbl}</span>
            <input type="range" min="${r.min}" max="${r.max}"
                   value="${r.val}" step="1"
                   oninput="updFX(this,'${r.id}','${r.unit}')">
            <span class="fx-v" id="${r.id}">${fmtFX(r.val, r.unit)}</span>
          </div>
        `).join('')}
      </div>
    `).join('');
}

function buildMacros() {
  const bar = document.getElementById('macrobar');
  bar.innerHTML =
    '<span class="mac-lbl">MAKRO</span>' +
    MACROS.map(m => `
      <div class="mkey" title="Kliknij lub skrót ${m.key}"
           onmousedown="triggerMacro(this,'${m.shortcutAction}')">
        <span class="mk-sh">${m.key}</span>
        <span class="mk-ac">${m.action}</span>
      </div>
    `).join('');
}

// ══════════════════════════════════════════════════════════════════
// AKCJE
// ══════════════════════════════════════════════════════════════════

function toggleMute(id) {
  const ch = CHANNELS.find(c => c.id === id);
  ch.muted = !ch.muted;
  const btn   = document.getElementById('mb-' + id);
  const thumb = document.getElementById('fh-' + id);
  btn.classList.toggle('muted', ch.muted);
  thumb.classList.toggle('muted-thumb', ch.muted);

  // Aktualizuj tray jeśli to mikrofon
  if (id === 'mic') {
    window.helixAPI?.tray.updateMicState(ch.muted);
  }
}

function toggleSolo(id) {
  const ch = CHANNELS.find(c => c.id === id);
  ch.solo = !ch.solo;
  document.getElementById('sb-' + id).classList.toggle('soloed', ch.solo);
  document.getElementById('ch-' + id).classList.toggle('is-solo',  ch.solo);
}

function toggleFX(key) {
  const def = FX_DEFS.find(f => f.key === key);
  def.on = !def.on;
  document.getElementById('tog-' + key).classList.toggle('on', def.on);
}

function fmtFX(v, unit) {
  if (unit === 'dB')  return (v >= 0 ? '+' : '') + v + 'dB';
  if (unit === ':1')  return v + ':1';
  return v + unit;
}

function updFX(inp, id, unit) {
  document.getElementById(id).textContent = fmtFX(parseInt(inp.value), unit);
}

function triggerMacro(el, action) {
  el.classList.add('flash');
  setTimeout(() => el.classList.remove('flash'), 160);

  if (action === 'mic-mute')  toggleMute('mic');
  if (action === 'mute-all')  CHANNELS.forEach(ch => {
    if (!ch.muted) toggleMute(ch.id);
  });
  if (action === 'reset')     CHANNELS.forEach(ch => {
    if (ch.muted) toggleMute(ch.id);
  });
}

// ══════════════════════════════════════════════════════════════════
// ANIMACJA MIERNIKÓW
// ══════════════════════════════════════════════════════════════════

function animateMeters() {
  animT += 0.06;
  CHANNELS.forEach(ch => {
    const fill = document.getElementById('mf-' + ch.id);
    if (!fill) return;
    if (ch.muted) { fill.style.height = '0'; return; }

    const base  = ch.vol / 100;
    const noise = Math.sin(animT * (2.1 + ch.id.length * 0.6)) * 0.11
                + Math.sin(animT * 6.8  + ch.id.length) * 0.05;
    const lvl   = Math.max(0, Math.min(1, base * 0.68 + noise * base));

    fill.style.height = Math.round(lvl * 100) + '%';
    fill.classList.toggle('peak', lvl > 0.80 && lvl <= 0.93);
    fill.classList.toggle('clip', lvl > 0.93);
  });
  animFrame = requestAnimationFrame(animateMeters);
}

// ══════════════════════════════════════════════════════════════════
// TITLEBAR & WINDOW CONTROLS
// ══════════════════════════════════════════════════════════════════

function setupTitlebar() {
  document.getElementById('btn-close').addEventListener('click', () => {
    window.helixAPI?.window.hide(); // ukryj do tray, nie wychodzi
  });

  document.getElementById('btn-min').addEventListener('click', () => {
    window.helixAPI?.window.minimize();
  });

  const btnAOT      = document.getElementById('btn-aot');
  const pillAOT     = document.getElementById('pill-aot-label');
  let   aotState    = false;

  btnAOT.addEventListener('click', async () => {
    aotState = await window.helixAPI?.window.toggleAlwaysOnTop();
    btnAOT.classList.toggle('aot-on', aotState);
    pillAOT.textContent = 'AOT: ' + (aotState ? 'ON' : 'OFF');
    pillAOT.classList.toggle('active', aotState);
  });

  // Virtual Cable toggle
  const pillVC = document.getElementById('pill-vc');
  pillVC.addEventListener('click', () => {
    vcOn = !vcOn;
    pillVC.textContent = 'VC: ' + (vcOn ? 'ON' : 'OFF');
    pillVC.classList.toggle('off', !vcOn);
    // TODO etap 2: faktyczny routing
  });

  // Ustawienia
  document.getElementById('btn-settings').addEventListener('click', openSettings);
  document.getElementById('sett-close').addEventListener('click', closeSettings);
  document.getElementById('settings-overlay').addEventListener('click', e => {
    if (e.target === e.currentTarget) closeSettings();
  });
}

// ══════════════════════════════════════════════════════════════════
// PANEL USTAWIEŃ
// ══════════════════════════════════════════════════════════════════

async function openSettings() {
  document.getElementById('settings-overlay').classList.remove('hidden');

  // Autostart
  const autostartOn = await window.helixAPI?.autostart.get() ?? false;
  const togAuto = document.getElementById('tog-autostart');
  togAuto.classList.toggle('on', autostartOn);
  togAuto.onclick = async () => {
    const newVal = !togAuto.classList.contains('on');
    togAuto.classList.toggle('on', newVal);
    await window.helixAPI?.autostart.set(newVal);
  };

  // AOT toggle w ustawieniach
  const togAOT = document.getElementById('tog-aot');
  const aotNow = await window.helixAPI?.window.isAlwaysOnTop() ?? false;
  togAOT.classList.toggle('on', aotNow);
  togAOT.onclick = async () => {
    const v = await window.helixAPI?.window.toggleAlwaysOnTop();
    togAOT.classList.toggle('on', v);
    document.getElementById('pill-aot-label').textContent = 'AOT: ' + (v ? 'ON' : 'OFF');
  };

  // VC toggle w ustawieniach
  const togVC = document.getElementById('tog-vc');
  togVC.classList.toggle('on', vcOn);
  togVC.onclick = () => { vcOn = !vcOn; togVC.classList.toggle('on', vcOn); };

  // Wersja
  const ver = await window.helixAPI?.app.version() ?? '0.1.0';
  document.getElementById('app-version').textContent = ver;

  // Nagrywanie skrótów klawiszowych
  setupShortcutInput('sc-mic-mute',    'mic-mute');
  setupShortcutInput('sc-toggle-win',  'toggle-win');
}

function closeSettings() {
  document.getElementById('settings-overlay').classList.add('hidden');
}

function setupShortcutInput(inputId, action) {
  const inp = document.getElementById(inputId);
  if (!inp) return;

  inp.addEventListener('click', () => {
    inp.classList.add('recording');
    inp.value = 'Naciśnij skrót...';

    const onKey = async (e) => {
      e.preventDefault();
      const parts = [];
      if (e.ctrlKey)  parts.push('Ctrl');
      if (e.altKey)   parts.push('Alt');
      if (e.shiftKey) parts.push('Shift');
      if (e.key !== 'Control' && e.key !== 'Alt' && e.key !== 'Shift') {
        parts.push(e.key.length === 1 ? e.key.toUpperCase() : e.key);
      }
      if (parts.length >= 2) {
        const combo = parts.join('+');
        inp.value = combo;
        inp.classList.remove('recording');
        document.removeEventListener('keydown', onKey, true);
        const ok = await window.helixAPI?.shortcut.register(combo, action);
        if (!ok) inp.value = 'Błąd rejestracji';
      }
    };

    document.addEventListener('keydown', onKey, true);

    // Timeout: anuluj po 5s
    setTimeout(() => {
      inp.classList.remove('recording');
      document.removeEventListener('keydown', onKey, true);
      if (inp.value === 'Naciśnij skrót...') inp.value = '';
    }, 5000);
  });
}

// ══════════════════════════════════════════════════════════════════
// IPC — odbiór z main process / tray
// ══════════════════════════════════════════════════════════════════

function setupIPC() {
  // Skrót globalny mic mute
  window.helixAPI?.shortcut.onMicMute(() => toggleMute('mic'));

  // Tray: wycisz mic
  window.helixAPI?.shortcut.onToggleMute(() => toggleMute('mic'));
}

// ══════════════════════════════════════════════════════════════════
// ANIMACJA CPU (symulacja — etap 3 zastąpi prawdziwymi danymi)
// ══════════════════════════════════════════════════════════════════

function startStatusUpdates() {
  setInterval(() => {
    const cpu = Math.round(1 + Math.random() * 5);
    document.getElementById('pill-cpu').textContent = 'CPU ' + cpu + '%';
  }, 2000);
}

// ══════════════════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  buildChannels();
  buildFX();
  buildMacros();
  setupTitlebar();
  setupIPC();
  startStatusUpdates();
  animateMeters();

  // Zaznacz kanał mic jako aktywny
  document.getElementById('ch-mic')?.classList.add('is-active');
});
