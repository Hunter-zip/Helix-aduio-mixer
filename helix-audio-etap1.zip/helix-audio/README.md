# HELIX Audio Mixer

> Lekki mikser audio dla Windows — Electron + Web Audio API

## Wymagania

- **Node.js** 18+ (https://nodejs.org)
- **Windows 10/11** (do pełnych funkcji audio)
- **VB-Cable** (opcjonalne, do routingu) — https://vb-audio.com/Cable/

---

## Szybki start

```bash
# 1. Wejdź do folderu projektu
cd helix-audio

# 2. Zainstaluj zależności
npm install

# 3. Uruchom
npm start
```

---

## Skróty klawiszowe (domyślne)

| Skrót           | Akcja                  |
|-----------------|------------------------|
| `Ctrl+Alt+M`    | Wycisz / przywróć mic  |
| `Ctrl+Alt+H`    | Pokaż / ukryj okno     |

Można zmienić w **Ustawienia (⚙) → Skróty klawiszowe**.

---

## Plan rozwoju

| Etap | Status     | Opis                                              |
|------|-----------|---------------------------------------------------|
| 1    | ✅ Gotowy  | UI + Tray + Autostart + Skróty globalne           |
| 2    | 🔜 Następny | Audio routing (Web Audio API + Virtual Cable)    |
| 3    | ⏳ Planowany | Per-app volume (WASAPI native addon)             |
| 4    | ⏳ Planowany | Efekty głosowe (noise gate, EQ, compressor)     |
| 5    | ⏳ Planowany | Noise suppression / echo cancel (RNNoise WASM)  |
| 6    | ⏳ Planowany | Makro klawisze z edytorem                       |
| 7    | ⏳ Planowany | Integracja OBS (obs-websocket)                  |

---

## Struktura projektu

```
helix-audio/
├── main.js          ← Electron main process (okno, tray, IPC)
├── preload.js       ← Bezpieczny most IPC
├── renderer/
│   ├── index.html   ← Struktura UI
│   ├── style.css    ← Style (dark, monospace)
│   └── renderer.js  ← Logika UI
├── assets/          ← Ikony (generowane automatycznie)
└── package.json
```

---

## Uwagi

- Ikona tray jest generowana programatycznie (brak zewnętrznych zależności na obrazki)
- Mierniki poziomów audio są na razie animowane — zostaną podłączone do Web Audio API w etapie 2
- Per-app volume wymaga natywnego modułu Node (etap 3) — na Windows używa WASAPI
