const {
  app, BrowserWindow, Tray, Menu, ipcMain,
  nativeImage, globalShortcut, shell, dialog
} = require('electron');
const path = require('path');
const { deflateSync } = require('zlib');

// ─── Stan aplikacji ──────────────────────────────────────────────
let mainWindow = null;
let tray       = null;
let isQuitting = false;

const WINDOW_W = 870;
const WINDOW_H = 620;

// ─── Generowanie ikony tray (16x16 PNG bez zewnętrznych zależności) ──
function makeTrayIconBuffer() {
  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (const byte of buf) {
      c ^= byte;
      for (let i = 0; i < 8; i++) c = (c >>> 1) ^ (0xEDB88320 * (c & 1));
    }
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  function chunk(type, data) {
    const len  = Buffer.allocUnsafe(4); len.writeUInt32BE(data.length);
    const t    = Buffer.from(type);
    const crcN = Buffer.allocUnsafe(4);
    crcN.writeUInt32BE(crc32(Buffer.concat([t, data])));
    return Buffer.concat([len, t, data, crcN]);
  }
  const W = 16, H = 16;
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4);
  ihdr[8] = 8; ihdr[9] = 6; // 8-bit RGBA

  // Rysuj ikonę: czarne tło, biała litera H (5x7 pikseli)
  const px = Buffer.alloc(H * (1 + W * 4), 0);
  const set = (x, y, r, g, b, a = 255) => {
    if (x < 0 || x >= W || y < 0 || y >= H) return;
    const i = y * (1 + W * 4) + 1 + x * 4;
    px[i] = r; px[i+1] = g; px[i+2] = b; px[i+3] = a;
  };
  // tło ciemne
  for (let y = 0; y < H; y++) {
    px[y * (1 + W * 4)] = 0; // filter byte
    for (let x = 0; x < W; x++) set(x, y, 20, 20, 20, 255);
  }
  // litera H (biała, 3x7 na pozycji 3,4)
  const HH = [[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[1,3],[2,0],[2,1],[2,2],[2,3],[2,4],[2,5],[2,6]];
  for (const [dx, dy] of HH) set(3+dx, 4+dy, 255, 255, 255);

  return Buffer.concat([
    Buffer.from([137,80,78,71,13,10,26,10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(px)),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// ─── Tworzenie okna głównego ──────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width:  WINDOW_W,
    height: WINDOW_H,
    minWidth:  720,
    minHeight: 500,
    frame:     false,          // własny titlebar
    resizable: true,
    transparent: false,
    backgroundColor: '#0f0f0f',
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    show: false,               // czekamy na ready-to-show
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Zamknięcie → chowaj do tray zamiast wychodzić
  mainWindow.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      if (tray) {
        tray.displayBalloon({
          iconType: 'info',
          title:    'HELIX działa w tle',
          content:  'Kliknij ikonę w tray aby przywrócić.',
        });
      }
    }
  });

  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }
}

// ─── Tray ────────────────────────────────────────────────────────
function createTray() {
  const icon = nativeImage.createFromBuffer(makeTrayIconBuffer());
  tray = new Tray(icon);
  tray.setToolTip('HELIX Audio Mixer');

  const buildMenu = (micMuted = false) => Menu.buildFromTemplate([
    {
      label:   `Mikrofon: ${micMuted ? '🔴 WYCISZONY' : '🟢 Aktywny'}`,
      enabled: false,
    },
    { type: 'separator' },
    {
      label: 'Pokaż HELIX',
      click: () => { mainWindow.show(); mainWindow.focus(); },
    },
    {
      label:   'Wycisz mikrofon',
      type:    'checkbox',
      checked: micMuted,
      click:   (item) => {
        mainWindow.webContents.send('tray:toggle-mic-mute');
        tray.setContextMenu(buildMenu(item.checked));
      },
    },
    { type: 'separator' },
    {
      label: 'Uruchom przy starcie Windows',
      type:  'checkbox',
      checked: app.getLoginItemSettings().openAtLogin,
      click: (item) => {
        app.setLoginItemSettings({ openAtLogin: item.checked });
      },
    },
    { type: 'separator' },
    {
      label: 'Zamknij HELIX',
      click: () => { isQuitting = true; app.quit(); },
    },
  ]);

  tray.setContextMenu(buildMenu());
  tray.on('double-click', () => {
    mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
  });

  // Aktualizuj menu tray gdy zmieni się stan mute
  ipcMain.on('tray:update-mic-state', (_, muted) => {
    tray.setContextMenu(buildMenu(muted));
    tray.setToolTip(`HELIX — mikrofon ${muted ? 'WYCISZONY' : 'aktywny'}`);
  });
}

// ─── Globalne skróty klawiszowe ───────────────────────────────────
function registerShortcuts() {
  // Domyślne skróty — renderer może je zmienić przez IPC
  const shortcuts = {
    'Ctrl+Alt+M': () => mainWindow.webContents.send('shortcut:mic-mute'),
    'Ctrl+Alt+H': () => {
      mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
    },
  };

  for (const [key, fn] of Object.entries(shortcuts)) {
    const ok = globalShortcut.register(key, fn);
    if (!ok) console.warn(`[HELIX] Nie można zarejestrować skrótu: ${key}`);
  }
}

// ─── IPC Handlers ────────────────────────────────────────────────
function setupIPC() {
  // Kontrolki okna
  ipcMain.handle('window:minimize',         () => mainWindow.minimize());
  ipcMain.handle('window:hide',             () => mainWindow.hide());
  ipcMain.handle('window:close',            () => { isQuitting = true; app.quit(); });
  ipcMain.handle('window:toggle-always-on-top', () => {
    const val = !mainWindow.isAlwaysOnTop();
    mainWindow.setAlwaysOnTop(val);
    return val;
  });
  ipcMain.handle('window:is-always-on-top', () => mainWindow.isAlwaysOnTop());

  // Autostart
  ipcMain.handle('autostart:get', () => app.getLoginItemSettings().openAtLogin);
  ipcMain.handle('autostart:set', (_, enable) => {
    app.setLoginItemSettings({ openAtLogin: enable });
  });

  // Rejestracja skrótu klawiszowego z renderera
  ipcMain.handle('shortcut:register', (_, { key, action }) => {
    try {
      globalShortcut.unregisterAll();
      registerShortcuts(); // przywróć domyślne
      const ok = globalShortcut.register(key, () => {
        mainWindow.webContents.send(`shortcut:${action}`);
      });
      return ok;
    } catch {
      return false;
    }
  });

  // Info o wersji
  ipcMain.handle('app:version', () => app.getVersion());

  // Otwórz link zewnętrzny
  ipcMain.handle('shell:open', (_, url) => shell.openExternal(url));
}

// ─── Inicjalizacja aplikacji ──────────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  createTray();
  setupIPC();
  registerShortcuts();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // nie wychodź — tray jest aktywny
  }
});

app.on('activate', () => {
  if (mainWindow) mainWindow.show();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

app.on('second-instance', () => {
  if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
});

// Tylko jedna instancja
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
