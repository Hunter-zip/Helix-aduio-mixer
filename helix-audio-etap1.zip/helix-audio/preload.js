const { contextBridge, ipcRenderer } = require('electron');

// Bezpieczny most między main process a renderererem
contextBridge.exposeInMainWorld('helixAPI', {
  // Kontrolki okna
  window: {
    minimize:          () => ipcRenderer.invoke('window:minimize'),
    hide:              () => ipcRenderer.invoke('window:hide'),
    close:             () => ipcRenderer.invoke('window:close'),
    toggleAlwaysOnTop: () => ipcRenderer.invoke('window:toggle-always-on-top'),
    isAlwaysOnTop:     () => ipcRenderer.invoke('window:is-always-on-top'),
  },

  // Autostart
  autostart: {
    get: ()        => ipcRenderer.invoke('autostart:get'),
    set: (enable)  => ipcRenderer.invoke('autostart:set', enable),
  },

  // Globalne skróty
  shortcut: {
    register: (key, action) => ipcRenderer.invoke('shortcut:register', { key, action }),
    onMicMute:    (cb) => ipcRenderer.on('shortcut:mic-mute',    () => cb()),
    onToggleMute: (cb) => ipcRenderer.on('tray:toggle-mic-mute', () => cb()),
  },

  // Tray
  tray: {
    updateMicState: (muted) => ipcRenderer.send('tray:update-mic-state', muted),
  },

  // Info
  app: {
    version: () => ipcRenderer.invoke('app:version'),
  },

  shell: {
    open: (url) => ipcRenderer.invoke('shell:open', url),
  },
});
